using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace KMS.Monster.Interface
{
    public interface IStaggerable
    {
        void Stagger();
    }
}