using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IMentalStamina
{
    void ReduceMental(float amount);
}