using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum MonsterPerceptionState
{
    Idle,
    Suspicious,
    Search,
    Alert,
    Combat
}
